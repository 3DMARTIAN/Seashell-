# Website Kerang 🐚

Project website sederhana bertema kerang.

## Fitur
- Halaman utama
- Galeri gambar
- Desain sederhana

## Cara Menjalankan
Buka file `index.html` di browser.
